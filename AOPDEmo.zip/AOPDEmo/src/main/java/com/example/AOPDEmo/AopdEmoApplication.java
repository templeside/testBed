package com.example.AOPDEmo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AopdEmoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AopdEmoApplication.class, args);
	}

}
