package com.example.AOPDEmo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopdEmoApplicationTests {

	@Test
	void contextLoads() {
	}

}
