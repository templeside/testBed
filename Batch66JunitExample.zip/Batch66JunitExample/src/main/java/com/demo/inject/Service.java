package com.demo.inject;

public interface Service {
	public boolean send(String msg);

}
