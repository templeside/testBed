package com.example.FirstBootProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstBootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstBootProjectApplication.class, args);
	}

}
