package com.springboot3security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot3SecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot3SecurityApplication.class, args);
	}

}
